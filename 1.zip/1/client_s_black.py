# - *- coding: utf- 8 - *
import requests
import os
import io
import json
from bs4 import BeautifulSoup
import re
from datetime import datetime
import locale
import random
from random import randrange
import time
import datetime
from requests_toolbelt import MultipartEncoder
os.chdir(os.path.dirname(os.path.abspath(__file__)))
import html
from fake_useragent import UserAgent
from urllib3.util import parse_url, Url
from urllib.parse import quote
import telegram



class HumanRun:
        mapHeader={}
        confirmOffer_complete_value=' '
        offer_confirm_value=' '
        offerDetail_mailto_value=' '
        errstr="恐れ入れますが、しばらく経ってから再度申込していただきますようにお願いいたします"
        ten,ho,tenka,hoka,sex,sinhnhat,phone,datnuoc,datnuocbang='','','','','','','','',''
        codetext=''
        def gen_phone(self):
            return str(random.choice(['080-','070-','090-']))+str(''.join(random.choices('0123456789', k = random.randint(3,4))))+'-'+ str(''.join(random.choices('0123456789', k = 4)))#電話番号

        def generatebirth(self):
            for i in range(0,5000):
                DOB = (random.choice(["1980", "1981", "1982", "1983", "1984", "1985", "1986", 
                "1987", "1988", "1989", "1990", "1991", "1992", "1993", "1994", "1996", 
                "1997", "1998", "1999", "2000"])+random.choice(["01", "02", "03", "04", "05", "06", "07", "08", "09", 
                "10", "11", "12"]) + random.choice(["01", "02", "03", "04", "05", "06", 
                "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", 
                "20", "21", "22", "23", "24", "25", "26", "27", "28"]))
                return DOB

        # birth=['20000825','19960103','19940515','19991006','20010816','19900528','19940716',
        #        '20010222','19930317','19920216','19921223','20000517','19951112','19931019',
            #    '19980825','19961203','19940917','19960815']
        
        s = None
        _TRANSACTION_TOKEN, _csrf="",""
        is_logined=False
        numbercode=''
        username_=''
        choiceid=-1
        tel=['080-2640-0078','070-8571-7167','070-9074-8748','090-6089-7436']
        htel=['080-','070-','090-']
        # tel=['080-2640-0078','070-8571-7167','070-9074-8748','090-6089-7436'] #
        serialOfferList,serialOfferDetail,agreeSize,serialOffer,serialRenkei,agreement='','','','','',''
        match_str="Hirabari Exchanging Foreign Driver's License"
        is_click,html_=False,""
        applicant_lastName=['NGUYEN','TRAN','LE','PHAM','HOANG','PHAN','VU','VO','DANG','BUI','DO','HO','NGO','DUONG','LY']
        applicant_lastNameKATA=['グエン','チャン','レ','ファム','ホアン','ファン','ヴ','ヴォー','ダン','ブイ','ドー','ホー','ゴー','ズオン','ﾘｲ']
        applicant_firstName=['HUY','KHANG','BAO','MINH','PHUC','ANH','KHOA','PHAT','DAT','KHOI','LONG','NAM','DUY','QUAN','KIET','THINH','TUAN','HUNG',
        'HOANG','HIEU','NHAN','TRI','TAI','PHONG','NGUYEN','AN','PHU','THANH','DUC','DUNG','LOC','KHANH','VINH','TIEN','NGHIA','THIEN',
        'HAO','HAI','DANG','QUANG','LAM','NHAT','TRUNG','THANG','TU','HUNG','TAM','SANG','THAI','CUONG','VU','TOAN','AN','THUAN','BINH',
        'TRUONG','DANH','KIEN','PHUOC','THIEN','TAN','VIET','KHAI','TIN','DUONG','TUNG','QUY','HAU','TRONG','TRIET','LUAN','PHUONG','QUOC',
        'THONG','KHIEM','HOA','THANH','TUONG','KHA','VY','BACH','KHANH','MANH','LOI','HIEP','DONG','NHUT','GIANG','KY','PHI','TAN','VAN',
        'VUONG','CONG','HIEN','LINH','NGOC','VI']
        applicant_firstNameKATA=['フイ','カン','バオ','ミン','フック','アン','コア','ファット','ダット','コイ','ロン','ナム','デュイ','クアン','キエット','シン','トゥアン','フン',
        'ホアン','ヒエウ','ニャン','トリ','タイ','フォン','グエン','アン','フー','タン','ドゥク','ズン','ロク','カーン','ヴィン','進捗','ギア','ティエン',
        'ハオ','ハイ','ダン','クアン','ラム','ニャット','チュン','タン','トゥ','フン','タム','サン','タイ','クオン','ヴ','トアン','アン','トゥアン','ビン',
        'チュオン','ダン','キエン','フック','ティエン','タン','ベト','カイ','ティン','ズオン','トン','クイ','ハウ','トロン','トリエット','ルアン','フォン','クオック',
        'トン','キエム','ホア','タン','トゥオン','カ','ヴィ','バッハ','カーン','マン','ロイ','ヒプ','ドン','ヌット','ザン','カイ','ファイ','タン','ヴァン',
        'キング','キング','ヒエン','リン','ジェイド','ウェイ']
        list_info_random={}
        list_info_random_tmp={}
        list_info_chidinh={}
        list_info_chidinh_tmp={}
        

        ua = UserAgent()
        useragent=ua.getRandom['useragent']
        print(ua.getRandom['useragent'])
        Referer=''
        listkeyheader=['offerList_initDisplay','offerList_searchOfferList','offerList_movePage','userLogin','userLogin_login','offerList_detail',
                       'offerDetail_mailto','offer_confirm','confirmOffer_complete','inquiry_initDisplay','inquiry_inquiry','inquiryDetail_update','updateInquiry_confirm','confirmUpdInquiry_update']
        
        
        def getheader(self,name):
            sos=self.mapHeader[name]
            if self.Referer!='':sos['Referer']=self.Referer
            return sos
            
        def getAccounts(self):
            list_accounts={}
            with open('data/user.txt', encoding='utf8') as f:
                for line in f:
                    txt=line.strip()
                    x = txt.split("	")
                    if (len(x)>=2):
                        list_accounts[x[0]]=x[0],x[1]


            shuffled = list(list_accounts.values())
            random.shuffle(shuffled)
            po =random.randint(0,len(shuffled)-1)
            
            return shuffled[po]


            
        def get_contry(self,idcountry):
            datnuoc_,datnuocbang_='',''
            if idcountry=="1":#vietnam
                datnuoc_='ベトナム'
                datnuocbang_='ベトナム'
            elif idcountry=="0":# brazil
                datnuoc_='ブラジル'
                datnuocbang_='ブラジル'
            elif idcountry=="2":# philippin
                datnuoc_='フィリピン'
                datnuocbang_='フィリピン'
            elif idcountry=="3":# indonesia
                datnuoc_='インドネシア'
                datnuocbang_='インドネシア'
            return datnuoc_,datnuocbang_
    
        def getheaderfile(self,id):
            header={}
            path=''
            if (id=="offerList_initDisplay"):
                path='data/header/offerList_initDisplay.txt'
            elif (id=="offerList_searchOfferList"):
                path='data/header/offerList_searchOfferList.txt'
            elif (id=="offerList_movePage"):
                path='data/header/offerList_movePage.txt'
            elif (id=="userLogin"):
                path='data/header/userLogin.txt'
            elif (id=="userLogin_login"):
                path='data/header/userLogin_login.txt'
            elif (id=="offerList_detail"):
                path='data/header/offerList_detail.txt'
            elif (id=="offerDetail_mailto"):
                path='data/header/offerDetail_mailto.txt'
            elif (id=="offer_confirm"):
                path='data/header/offer_confirm.txt'
            elif (id=="confirmOffer_complete"):
                path='data/header/confirmOffer_complete.txt'
            elif (id=="inquiry_initDisplay"):
                path='data/header/inquiry_initDisplay.txt'
            elif (id=="inquiry_inquiry"):
                path='data/header/inquiry_inquiry.txt'
            elif (id=="inquiryDetail_update"):
                path='data/header/inquiryDetail_update.txt'
            elif (id=="updateInquiry_confirm"):
                path='data/header/updateInquiry_confirm.txt'
            elif (id=="confirmUpdInquiry_update"):
                path='data/header/confirmUpdInquiry_update.txt'

            with open(path, encoding='utf8') as f:
                for line in f:
                    txt=line.strip()
                    x = txt.split(":")
                    if (len(x)>0):
                        header[x[0]]=x[1].strip()
            header['User-Agent']=self.useragent
            return header
        
        
        
        
        def LoadHeader(self):
            for l in self.listkeyheader:
               self.mapHeader[l] =self.getheaderfile(l)
            # print(self.mapHeader['offer_confirm'])
     
        def Setcookies(self,refurl):
            global s
            # s.cookies.set('CookiePclogoUrl','downloader?fileId=3536c8be98d800ca5aaaf360c4435a1e2b16a906f2edeadef6a693f351e4be3edade5fc9b40044471d35879cab1d4a1c02e82327b898810da8484b57edfc55cd20150305015150')
            s.cookies.set('cookieColorCss','title')
            # s.cookies.set('CookieSplogoUrl','downloader?fileId=3536c8be98d800ca5aaaf360c4435a1e2b16a906f2edeadef6a693f351e4be3e0e5898d4969455051d35879cab1d4a1c02e82327b898810da8484b57edfc55cd20150305015150')
            s.cookies.set('CookiePcHelpUrl','/help/PREFAC/')
            s.cookies.set('CookieSpHelpUrl','/help/PREFAC/')
            s.cookies.set('CookiePcFaqUrl','/help/PREFAC/faq4-2.htm')
            s.cookies.set('CookieSpFaqUrl','/help/PREFAC/faq4-2.htm')
            s.cookies.set('CookieDefaultColor','b')
            s.cookies.set('CookieFontOn','true')
            if (refurl!=None): self.Referer=refurl

        def add_creds_to_proxy_url( self,url, username, password):
            url_dict = parse_url(url)._asdict()
            url_dict['auth'] = username + ':' + quote(password, '')
            return Url(**url_dict).url
        
        def getrandomproxy(self):
            global ten,ho,tenka,hoka,sex,sinhnhat,phone,datnuoc,datnuocbang
            global s
            # print(ten,ho,tenka,hoka,sex,sinhnhat,phone,datnuoc,datnuocbang)
            try:
                with open('proxy.txt', encoding='utf8') as fr:
                    lines = fr.readlines() 
                    random_line = random.choice(lines) if lines else None 
                    x = random_line.split(":")
                    if (len(x)>=3):
                        print(x[0],x[1],x[2]) 
                        proxy_url_credentials = self.add_creds_to_proxy_url('http://'+x[0]+':'+x[1], str(x[2]), str(x[3]).replace('\n',''))
                        # print(proxy_url_credentials)
                        proxies = {'http': proxy_url_credentials, 'https': proxy_url_credentials}
                        s.proxies.update(proxies)
                        print('da cai proxy: ',x)
                        r=s.get('https://www.myip.com/', verify=False)
                        soup = BeautifulSoup(html.unescape(r.text), "html.parser")
                        ip=soup.find("span", {"id": "ip"})
                        print(ip)
                    else: print('khong co proxy')
            except Exception as e:
                print(e)
                print('khong cai duoc proxy: ')

        def setproxy(self,host,username,pas):
            global s
            try:
                proxy_url_credentials = self.add_creds_to_proxy_url(host,username,pas)
                proxies = {'http': proxy_url_credentials, 'https': proxy_url_credentials}
                s.proxies.update(proxies)
                print('da cai proxy: ',host,username,pas)
                r=s.get('https://www.myip.com/', verify=False)
                soup = BeautifulSoup(html.unescape(r.text), "html.parser")
                ip=soup.find("span", {"id": "ip"})
                print(ip)
            except Exception as e:
                print(e)
                print('khong cai duoc proxy: ',host,username,pas)

        def getip_ipv4(self):
            try:
                r=requests.get('http://ipv4.icanhazip.com')
                print(r.text)
                return r.text.replace('\n','')
            except Exception as e:
                print(e)
                return None

        def getproxylist(self):
            list_proxy={}
            ip_ =self.getip_ipv4()
            if (ip_==None):
                print('exit')
                exit()
            with open('data/proxy.txt', encoding='utf8') as f:
                for line in f:
                    txt=line.strip()
                    x = txt.split(":")
                    if (len(x)>=4):
                        list_proxy[x[1]]='http://'+ip_+':'+x[1],x[2],x[3]
                        # list_proxy[x[1]]='http://'+x[0]+':'+x[1],x[2],x[3]
            shuffled = list(list_proxy.values())
            random.shuffle(shuffled)
            list_proxy=dict(zip(list_proxy, shuffled))
            random.shuffle(list_proxy)
            po =random.randint(0,len(list_proxy)-1)
            return list_proxy[po]
            
        def getlistinfo_chidinh():
            global list_info_chidinh
            # ten,ho,tenka,hoka,sex,sinhnhat,phone,datnuoc,datnuocbang='','','','','','','','',''
            count_=0
            with open('data/inforuser.txt', encoding='utf8') as f:
                for line in f:
                    txt=line.strip()
                    x = txt.split("	")
                    if (len(x)>=5):
                        tmp_=[x[1],x[0],'','',x[3],x[2],x[4],'151','150']
                        list_info_chidinh[count_]=tmp_
                        count_=count_+1
            return list_info_chidinh
            
        def random_name_sex_phone_vv(self):
                self.list_info_random
                count_=0
                if len(self.list_info_random)<1:
                    with open('data/hoten.txt', encoding='utf8') as f:
                        for line in f:
                            txt=line.strip()
                            x = txt.split("	")
                            if (len(x)>=5):
                                idcountry=x[5]
                                datnuoc,datnuocbang=self.get_contry(idcountry)
                                phone=str(self.gen_phone())
                                sinhnhat=self.generatebirth()
                                self.list_info_random[count_]=x[2],x[1],x[3],x[0],x[4] ,sinhnhat,phone,datnuoc,datnuocbang
                                count_=count_+1
                                
                shuffled = list(self.list_info_random.values())
                random.shuffle(shuffled)
                self.list_info_random=dict(zip(self.list_info_random, shuffled))
                random.shuffle(self.list_info_random)
                po =random.randint(0,len(self.list_info_random)-1)
                return self.list_info_random[po]



        def __init__(self):
            global ten,ho,tenka,hoka,sex,sinhnhat,phone,datnuoc,datnuocbang
            global s
            s = requests.Session() 
            print('created bot!')
            self.LoadHeader()
            
            # print(self.random_name_sex_phone_vv())
            # ten,ho,tenka,hoka,sex,sinhnhat,phone,datnuoc,datnuocbang=self.random_name_sex_phone_vv()
            # self.getrandomproxy()
            # self.random_name_sex_phone_vv()
        def Setup___(self,info,codetext_):
            global ten,ho,tenka,hoka,sex,sinhnhat,phone,datnuoc,datnuocbang,codetext
            ten,ho,tenka,hoka,sex,sinhnhat,phone,datnuoc,datnuocbang=info[5],info[6],info[7],info[8],info[9],info[10],info[11],info[12],info[13]
            codetext=codetext_
        def update_info(self,ho_,_ten_,sex_,sinhnhat_,phone_,datnuoc_,datnuocbang_):
            global ten,ho,sex,sinhnhat,phone,datnuoc,datnuocbang
            ho,ten,sex,sinhnhat,phone,datnuoc,datnuocbang=ho_,_ten_,sex_,sinhnhat_,phone_,datnuoc_,datnuocbang_
            
        def login(self, username,pass_):
            global _csrf,is_logined,s,numbercode,username_
            username_=username
            TOKEN_, _csrf, is_logined= self.login_home(username,pass_) #('onsenchyan@gmail.com','123456')
            print(username,pass_,is_logined)
            return is_logined

        def getTokenFromHtml(self,strhtml):
            soup = BeautifulSoup(html.unescape(strhtml), "html.parser")
            value1,value2="",""
            try:
                value1 = soup.find('input', {'name': '_TRANSACTION_TOKEN'}).get('value')
                # print(value)
            except Exception as e:
                print("Err:","_TRANSACTION_TOKEN")
            try:
                value2 = soup.find('input', {'name': '_csrf'}).get('value')
                print(value2)
            except Exception as e:
                print("Err:","_csrf")
            return value1,value2

        def login_home(self,user,password):
            global s,numbercode
            try:
                url='https://www.shinsei.e-aichi.jp/pref-aichi-police-u/profile/userLogin'
                r = s.get(url,headers=self.getheader('userLogin'),timeout=5)
                self.Setcookies(url)

                _TRANSACTION_TOKEN, _csrf=self.getTokenFromHtml(r.text)
                if _TRANSACTION_TOKEN!="" :
                    postdatalogin ={'userId':user,'userPasswd':password,'nextURL':'','nextURLForMoj':'','accessFrom':'','nextURLForCorona':'',
                            'serialOfferTemporarySeq':'','javaScriptEffectiveFlag':'true',
                            '_TRANSACTION_TOKEN':_TRANSACTION_TOKEN,'_csrf':_csrf}
                    
                    url='https://www.shinsei.e-aichi.jp/pref-aichi-police-u/profile/userLogin_login'
                    r = s.post(url, data =postdatalogin,headers=self.getheader('userLogin_login'),timeout=5)
                    self.Setcookies(None)
                    # r = s.post('https://www.shinsei.e-aichi.jp/pref-aichi-police-u/profile/userLogin_login', data =postdatalogin)
                    text_=r.text
                    _TRANSACTION_TOKEN_, _csrf_=self.getTokenFromHtml(text_)
                    soup = BeautifulSoup(html.unescape(text_), "html.parser")
                    # with io.open('D:/AUTOALL/AUTODANGKI-SEINGOAN/log/userLogin'+numbercode+'.html', 'w', encoding="utf-8") as file:
                    #     file.write(text_)
                return _TRANSACTION_TOKEN_, _csrf_,("ようこそ" in soup.getText())
            except: return None,None,False


        def logout(self,_csrf_):
            global s
            postdatalogin ={'javaScriptEffectiveFlag':'true','_csrf':_csrf_}
            s.post('https://www.shinsei.e-aichi.jp/pref-aichi-police-u/profile/userLogout_logout', data =postdatalogin)

        
        def offerList_detailTop_check(self,numbercode):
            global s
            # global ten,ho,tenka,hoka,sex,sinhnhat,phone,datnuoc,datnuocbang
            # print(ten,ho,tenka,hoka,sex,sinhnhat,phone,datnuoc,datnuocbang)
            try:
                # r = s.get('https://www.shinsei.e-aichi.jp/pref-aichi-police-u/offer/offerList_detailTop?tempSeq=' + numbercode,timeout=3)
                # print(r.status_code)

                self.Setcookies('https://www.shinsei.e-aichi.jp/pref-aichi-police-u/offer/offerList_searchOfferList')
                url='https://www.shinsei.e-aichi.jp/pref-aichi-police-u/offer/offerList_detail?tempSeq=' + numbercode+'&accessFrom=offerList'
                r = s.get(url,headers=self.getheader('offerList_detail'),timeout=3)
                self.Setcookies(url)
                
                soup = BeautifulSoup(html.unescape(r.text), "html.parser")
                # with io.open('D:/AUTOALL/AUTODANGKI-SEINGOAN/log/offerList_detailTop'+numbercode+'.html', 'w', encoding="utf-8") as file:
                #     file.write(r.text)
                find_element = soup.find_all('input', type="submit")
                for element in find_element:
                    try:
                        onclick=str(element.get('onclick'))
                        # print(onclick)
                        if ('offerDetail_mailto' in onclick):
                            print(numbercode,'co the dang ky duoc')
                            return True,r.text 
                    except Exception as e:
                        print(e)
                print(numbercode,datetime.datetime.now(),r.status_code,r.elapsed.total_seconds())
                # print(numbercode,'chiu thua!!')
        
                return False,r.text
        
                # return True,r.text
            except Exception as e: # work on python 3.x
                print(e)
                return False,None

        def login_guest(self,html_):
            soup = BeautifulSoup(html.unescape(html_), "html.parser")
            find_element = soup.find_all('input', type="hidden")
            for element in find_element:
                    try:
                        value=element.get('value')
                        name=element.get('name')
                        print(name)
                        # nextURL
                        
                    except Exception as e:
                        print(e)
                
                
          
        

        
        def offerDetail_mailto(self,html_):
            global s,numbercode,_csrf,offerDetail_mailto_value
            try:
                soup = BeautifulSoup(html.unescape(html_), "html.parser")
                find_element = soup.find_all('input', type="hidden")
                for element in find_element:
                    try:
                        name=element.get('name')
                        if name=="serialOfferList" :
                            self.serialOfferList=element.get('value')
                        elif name=="serialOfferDetail" :
                            self.serialOfferDetail=element.get('value')
                        elif name=="agreeSize" :
                            self.agreeSize=element.get('value')
                        elif name=="serialOffer" :
                            self.serialOffer=element.get('value')
                        elif name=="serialRenkei" :
                            self.serialRenkei=element.get('value')
                        elif name=="agreement" :
                            self.agreement=element.get('value')   
                        elif name=="_csrf" :
                            _csrf=element.get('value')   
                            
                    except Exception as e:
                        print(e)
                postdatalogin ={'serialOfferList':self.serialOfferList,'serialOfferDetail':self.serialOfferDetail,'agreeSize':self.agreeSize,'serialOffer':self.serialOffer,'serialRenkei':self.serialRenkei,'agreement':self.agreement,
                        '_csrf':_csrf}
                url='https://www.shinsei.e-aichi.jp/pref-aichi-police-u/offer/offerDetail_mailto'
                r = s.post(url,headers=self.getheader('offerDetail_mailto'),data =postdatalogin,timeout=5)
                print('offerDetail_mailto:',r.status_code,r.elapsed.total_seconds())
                self.Setcookies(url)
                offerDetail_mailto_value=r.text
                # r = s.post('https://www.shinsei.e-aichi.jp/pref-aichi-police-u/offer/offerDetail_mailto', data =postdatalogin,timeout=15)
                print('offerDetail_mailto:',r.status_code)
                return r.text
                
            except Exception as e: # work on python 3.x
                print('offerDetail_mailto ','err')
                return None
        



        def offer_confirm_Hirabari(self,html_):
            global s,numbercode,offer_confirm_value
            global ten,ho,tenka,hoka,sex,sinhnhat,phone,datnuoc,datnuocbang
            # ho,ten,sinhnhat,datnuoc,datnuocbang,phone= self.random_name_sex_phone_vv()
            try:
                # f = open("log/offerDetail_mailto.83326.bernardesellenlove.gmail.com.html", "r", encoding="utf-8")
                # soup = BeautifulSoup(html.unescape(f.read()), "html.parser")
                # print(datnuoc,datnuocbang)
                soup = BeautifulSoup(html.unescape(html_), "html.parser")
                SELECT=soup.find('select',{'name': 'item[2].selectData'})
                country_citizenship=SELECT.find('option',text=datnuoc).get('value')
                SELECT=soup.find('select',{'name': 'item[3].selectData'})
                country_driver_License=SELECT.find('option',text=datnuocbang).get('value')
                print(country_citizenship,country_driver_License)
                files = {
                    'item[0].textData':str(ho),  #applicant_lastName
                    'item[0].textData2':str(ten),#applicant_firstName
                    'item[0].itemSeq':str( soup.find('input',{'name': 'item[0].itemSeq'}).get('value')),
                    'item[1].textData':sinhnhat,
                    'item[2].selectData':country_citizenship,#Please enter your country of citizenship  ブラジル
                    'item[3].selectData':country_driver_License,#Please enter the country you are delivered on driver's License  ブラジル
                    'item[4].selectData':sex,#Gender
                    'item[4].textData':'',#
                    'item[5].textData': str(phone),
                    'item[6].textData':'',#２日以上の予約申請をした場合は多重予約となります Nếu bạn đăng ký đặt chỗ từ 2 ngày trở lên sẽ được coi là đặt chỗ nhiều lần.
                    'item[7].choiceList[0].checkFlag':'true',#申請内容の確認(Check Yourself) Xác nhận chi tiết đơn đăng ký (Kiểm tra chính mình)
                    '_item[7].choiceList[0].checkFlag': 'on',# Xác nhận chi tiết đơn đăng ký
                    'serialOffer':str(soup.find('input',{'name': 'serialOffer'} ).get('value')),#serialOffer
                    'templateSeq':str( soup.find('input',{'name': 'templateSeq'} ).get('value')),#templateSeq
                    'serialRenkei':str( soup.find('input',{'name': 'serialRenkei'} ).get('value')),#serialRenkei
                    'serialOfferDetail':str( soup.find('input',{'name': 'serialOfferDetail'} ).get('value')),#serialOfferDetail
                    'encryptKey':str( soup.find('input',{'name': 'encryptKey'} )),#encryptKey
                    'cookie':str( soup.find('input',{'name': 'cookie'} ).get('value')),#cookie
                    'javaScriptEffectiveFlag': 'true',#javaScriptEffectiveFlag
                    '_TRANSACTION_TOKEN':str( soup.find('input',{'name': '_TRANSACTION_TOKEN'} ).get('value')),#_TRANSACTION_TOKEN
                    '_csrf':str( soup.find('input',{'name': '_csrf'} ).get('value'))#_csrf
                }
                length_of_string = 30
                sample_str = "0123456789"
                generated_string = ''.join(random.choices(sample_str, k = length_of_string)) 
                m = MultipartEncoder(files,boundary='---------------------------'+str(generated_string))
                # print('offer_confirm:',m)
                # r = s.post('https://www.shinsei.e-aichi.jp/pref-aichi-police-u/offer/offer_confirmm',data=m, headers={'Content-Type': m.content_type},timeout=15)
               
                url='https://www.shinsei.e-aichi.jp/pref-aichi-police-u/offer/offer_confirm'
                # url='https://www.s'
                header_=self.getheader('offer_confirm')
                header_['Content-Type']=m.content_type
                r = s.post(url,headers=header_,data =m,timeout=5)
                print('offer_confirm:',r.status_code,r.elapsed.total_seconds())
                self.Setcookies(url)
                # print('offer_confirm',r.request.headers)
                offer_confirm_value=r.text
               
                # if (r.status_code==200):
                soup = BeautifulSoup(html.unescape(r.text), "html.parser")
                strr=soup.getText()
                if '申込確認' in strr:
                    return True,r.text 
                return False,None
            except Exception as e:
                print('offer_confirm : ', 'err')
                return False,None

        def offer_confirm_HGY(self,html_):
                global s,numbercode
                global ten,ho,tenka,hoka,sex,sinhnhat,phone,datnuoc,datnuocbang
            # try:
                soup = BeautifulSoup(html.unescape(html_), "html.parser")
                posho=random.randint(0,len(self.applicant_lastName)-1)
                posten=random.randint(0,len(self.applicant_firstName)-1)
                files = {
                    'item[0].textData':str(ho),  #applicant_lastName
                    'item[0].textData2': str(ten),#applicant_firstName
                    'item[0].itemSeq': str(soup.find('input',{'name': 'item[0].itemSeq'}).get('value')),
                    'item[0].textData2': str(self.applicant_firstName[random.randint(0,len(self.applicant_firstName)-1)]),#applicant_firstName
                    'item[1].textData':str(soup.find('input',{'name': 'item[1].textData'}).get('value')),  #fullNameKana1_1661558
                    'item[1].textData2':str( soup.find('input',{'name': 'item[1].textData2'}).get('value')),#fullNameKana2_1661558
                    
                    'item[2].textData':sinhnhat,
                    'item[2].selectData': "151",#Please enter your country of citizenship  ベトナム
                    'item[3].selectData': '1',#性別／Gender
                    'item[4].selectData': '1',#Gender
                    'item[4].textData':  '09060897436',#電話番号
                    'item[5].textData': 'YOKOHAMA HIRO DAIGAK',#Please enter the name of driver's school you graduated within 20
                    'item[6].selectData': '14',#Please select where the prefecture you graduated driver's school is located. Kanagawa
                    'item[7].textData': '',#Gender
                    'item[8].textData': '',#Gender
                    'item[9].textData': '',#Gender
                    'item[10].choiceList[0].checkFlag': 'true',#申請内容の確認(Check Yourself) Xác nhận chi tiết đơn đăng ký (Kiểm tra chính mình)
                    '_item[10].choiceList[0].checkFlag': 'on',# Xác nhận chi tiết đơn đăng ký
                    'serialOffer':str(soup.find('input',{'name': 'serialOffer'} ).get('value')),#serialOffer
                    'templateSeq': str(soup.find('input',{'name': 'templateSeq'} ).get('value')),#templateSeq
                    'serialRenkei': str(soup.find('input',{'name': 'serialRenkei'} ).get('value')),#serialRenkei
                    'serialOfferDetail': str(soup.find('input',{'name': 'serialOfferDetail'} ).get('value')),#serialOfferDetail
                    'encryptKey': str(soup.find('input',{'name': 'encryptKey'} )),#encryptKey
                    'cookie': str(soup.find('input',{'name': 'cookie'} ).get('value')),#cookie
                    'javaScriptEffectiveFlag': 'true',#javaScriptEffectiveFlag
                    '_TRANSACTION_TOKEN': str(soup.find('input',{'name': '_TRANSACTION_TOKEN'} ).get('value')),#_TRANSACTION_TOKEN
                    '_csrf': str(soup.find('input',{'name': '_csrf'}).get('value') )#_csrf
                }
                length_of_string = 30
                sample_str = "0123456789"
                generated_string = ''.join(random.choices(sample_str, k = length_of_string)) 
                m = MultipartEncoder(files,boundary='---------------------------'+str(generated_string))
           
                # r = s.post('https://www.shinsei.e-aichi.jp/pref-aichi-police-u/offer/offer_confirm',data=m, headers={'Content-Type': m.content_type},timeout=15)
                # print(r.status_code)
                url='https://www.shinsei.e-aichi.jp/pref-aichi-police-u/offer/offer_confirm'
                header_=self.getheader('offer_confirm')
                header_['Content-Type']=m.content_type
                r = s.post(url,headers=header_,data =m,timeout=5)
                print('offer_confirm:',r.status_code,r.elapsed.total_seconds())
                self.Setcookies(url)
                # print('offer_confirm',r.request.headers)
                with io.open('log/offer_confirmHGY'+numbercode+'.html', 'w', encoding="utf-8") as file:
                    file.write(r.text)
                if (r.status_code==200):
                        soup = BeautifulSoup(html.unescape(r.text), "html.parser")
                        strr=soup.getText()
                        if '申込確認' in strr:
                            return True,r.text 
                return False,None
            # except: return False,None


        def inquiry_initDisplay(self):
            global s
            try:
                url='https://www.shinsei.e-aichi.jp/pref-aichi-police-u/inquiry/inquiry_initDisplay'
                r = s.get(url,headers=self.getheader('inquiry_initDisplay'))
                print(datetime.datetime.now(),r.status_code,r.elapsed.total_seconds())
                self.Setcookies(url)
                soup = BeautifulSoup(html.unescape(r.text), "html.parser")
                _csrf=soup.find('input', {'name': '_csrf'}).get('value')  
                return _csrf
            except Exception as e: # work on python 3.x
                print(e)
                return None
            
        def inquiry_inquiry(self,_csrf,offerNumber,offerPassword):
            global s
           
            try:
                postdata={}
                postdata['offerNumber'] = offerNumber
                postdata['offerPassword'] = offerPassword
                postdata['javaScriptEffectiveFlag'] = 'true'
                postdata['_csrf'] = _csrf
                url='https://www.shinsei.e-aichi.jp/pref-aichi-police-u/inquiry/inquiry_inquiry'
                header_=self.getheader('inquiry_inquiry')
                r = s.post(url,headers=header_,data =postdata)
                print(datetime.datetime.now(),r.status_code,r.elapsed.total_seconds())
                self.Setcookies(url)
                report={}
                soup = BeautifulSoup(html.unescape(r.text), "html.parser")
                for checkbox in soup.find_all('input', checked=True):
                    print(checkbox.get('name'))
                    report[str(checkbox.get('id')) ]='on'
                report['_csrf']=soup.find('input', {'name': '_csrf'}).get('value')  
                report['_TRANSACTION_TOKEN']=soup.find('input', {'name': '_TRANSACTION_TOKEN'}).get('value') 
                report['serial']=soup.find('input', {'name': 'serial'}).get('value') 
                return report
            except Exception as e: # work on python 3.x
                print(e)
                return None
            
        def inquiryDetail_update(self,data_):
            global s
            global ten,ho,tenka,hoka,sex,sinhnhat,phone,datnuoc,datnuocbang
            try:
                url='https://www.shinsei.e-aichi.jp/pref-aichi-police-u/inquiry/inquiryDetail_update'
                header_=self.getheader('inquiryDetail_update')
                r = s.post(url,headers=header_,data =data_)
                print(datetime.datetime.now(),r.status_code,r.elapsed.total_seconds())
                self.Setcookies(url)
                report={}
                # print(r.text)
                soup = BeautifulSoup(html.unescape(r.text), "html.parser")
                SELECT=soup.find('select',{'name': 'item[2].selectData'})
                country_citizenship=SELECT.find('option',text=datnuoc).get('value')
                SELECT=soup.find('select',{'name': 'item[3].selectData'})
                country_driver_License=SELECT.find('option',text=datnuocbang).get('value')
                print(country_citizenship,country_driver_License)
                report['item[0].textData']=ho #nguyen van
                report['item[0].textData2']=ten #hoang lam
                report['item[0].itemSeq']=str( soup.find('input',{'name': 'item[0].itemSeq'}).get('value'))
                report['item[1].textData']=sinhnhat #19970211
                report['item[2].selectData']=country_citizenship  #151
                report['item[3].selectData']=country_driver_License #151
                report['item[4].selectData']=sex #1
                report['item[4].textData']=''                 
                report['item[5].textData']=phone #090-4789-469
                report['item[6].textData']=''
                report['item[7].choiceList[0].checkFlag']='true'  #true
                report['_item[7].choiceList[0].checkFlag']='on' 
                report['javaScriptEffectiveFlag']='true'
                report['encryptKey']=''
                report['_csrf']=soup.find('input', {'name': '_csrf'}).get('value')  
                report['serial']=soup.find('input', {'name': 'serial'}).get('value') 
                length_of_string = 30
                sample_str = "0123456789"
                generated_string = ''.join(random.choices(sample_str, k = length_of_string)) 
                m = MultipartEncoder(report,boundary='---------------------------'+str(generated_string))
                return m
            except Exception as e: # work on python 3.x
                print(e)
                return None
            
        def updateInquiry_confirm(self,data_):          
            global s
            try:
                url='https://www.shinsei.e-aichi.jp/pref-aichi-police-u/inquiry/updateInquiry_confirm'
                header_=self.getheader('updateInquiry_confirm')
                header_['Content-Type']=data_.content_type
                r = s.post(url,headers=header_,data =data_)
                print(datetime.datetime.now(),r.status_code,r.elapsed.total_seconds())
                self.Setcookies(url) 
                report={}
                soup = BeautifulSoup(html.unescape(r.text), "html.parser")
                for checkbox in soup.find_all('input', checked=True):
                    print(checkbox.get('name'))
                    report[str(checkbox.get('id')) ]='on'
                report['javaScriptEffectiveFlag']='true'
                report['serial']=soup.find('input', {'name': 'serial'}).get('value') 
                report['calledFrom']=''
                report['_TRANSACTION_TOKEN']=soup.find('input', {'name': '_TRANSACTION_TOKEN'}).get('value') 
                report['_csrf']=soup.find('input', {'name': '_csrf'}).get('value') 
                return report
            except Exception as e: # work on python 3.x
                print(e)
                return None
            
        def confirmUpdInquiry_update(self,data_):
            global s
            try:
                url='https://www.shinsei.e-aichi.jp/pref-aichi-police-u/inquiry/confirmUpdInquiry_update'
                header_=self.getheader('confirmUpdInquiry_update')
                r = s.post(url,headers=header_,data =data_)
                print(datetime.datetime.now(),r.status_code,r.elapsed.total_seconds())
                self.Setcookies(url) 
                if ('手続き内容の修正が完了しました' in r.text):
                    return 'Update thành công'
                else:
                    return None

            except Exception as e: # work on python 3.x
                print(e)
                return None

        def chuyenten(self,num_,pass_):
            text='Update lỗi'
            for i in range(2):
                _csrf=self.inquiry_initDisplay()
                if _csrf==None : continue
                obj=self.inquiry_inquiry(_csrf,num_,pass_)
                if obj==None : continue
                m=self.inquiryDetail_update(obj)
                if m==None : continue
                obj=self.updateInquiry_confirm(m)
                if obj==None : continue
                tetx_=self.confirmUpdInquiry_update(obj)
                if tetx_!=None: 
                    text=tetx_
                    break
                time.sleep(1)
            mess=text+'\n'+codetext+'\n'+ho+' '+ten+' '+sinhnhat+'\n'+username_+'\n'+ num_ + '\n' + pass_
            telegram.send_to_telegram(mess)

        def confirmOffer_complete(self,html_):
            global s,numbercode,username_,confirmOffer_complete_value
            global ten,ho,tenka,hoka,sex,sinhnhat,phone,datnuoc,datnuocbang,codetext
            
            # s=requests.Session()
            # numbercode='323444'
            # username_='shdgh@gmao.com'
            # ten='ha'
            # ho='cao'
            # sex='2'
            # sinhnhat='20102802'
            # phone='038-3734-6364'
            # datnuoc='ベトナム'
            # datnuocbang='ベトナム'
            
            username_=str(username_).replace('@','.')
            try:
                # f = open("log/trom/offer_confirm.83336.mrrodriguesana007.gmail.com.html", "r", encoding="utf-8")
                # soup = BeautifulSoup(html.unescape(f.read()), "html.parser")
                soup = BeautifulSoup(html.unescape(html_), "html.parser")
                find_element = soup.find_all('input',  checked=True)
                postdata={}
                for element in find_element:
                        try:
                            id=element.get('id')
                            postdata[id] = "on"
                        except Exception as e:
                            print(e)

                postdata['serialOffer'] = soup.find('input', {'name': 'serialOffer'}).get('value')     
                postdata['serialRenkei'] = soup.find('input', {'name': 'serialRenkei'}).get('value')   
                postdata['serialOfferDetail'] = soup.find('input', {'name': 'serialOfferDetail'}).get('value')  
                postdata['_TRANSACTION_TOKEN'] = soup.find('input', {'name': '_TRANSACTION_TOKEN'}).get('value')  
                postdata['_csrf'] = soup.find('input', {'name': '_csrf'}).get('value')  
                url='https://www.shinsei.e-aichi.jp/pref-aichi-police-u/offer/confirmOffer_complete'
                header_=self.getheader('confirmOffer_complete')
                r = s.post(url,headers=header_,data =postdata,timeout=5)
                print('confirmOffer_complete:',r.status_code,r.elapsed.total_seconds())
                tmp_=r.text
                confirmOffer_complete_value=r.text
                try:
                   
                    soup1 = BeautifulSoup(html.unescape(tmp_), "html.parser")
                    regex = re.compile('c-box--check__list')
                    dl=soup1.find("dl", {"class" : regex})
                    print(dl)
                    if dl!=None:
                        try:
                            mess=codetext+'\n'+ho+' '+ten+' '+sinhnhat+'\n'+username_+'\n'+dl.getText()
                            telegram.send_to_telegram(mess)
                            # dd=dl.findAll("dd")
                            # if (len(dd)>=2):
                                # self.chuyenten(str(dd[0].getText()),str(dd[1].getText()))
                        except Exception as e: 
                            print(e)
                        return tmp_
                    else:
                        return None
                except Exception as e:
                    print(e)
                    return None
                  

                    
            except Exception as e:
                print(e)
                return None
                
            
                
            # except Exception as e: # work on python 3.x
            #     print('confirmOffer_complete ',e)
            #     # with io.open('log/confirmOffer_complete'+numbercode+'.html', 'w', encoding="utf-8") as file:
            #     #     file.write('lỗi')
            #     return None
            
        def Print_log(self):
            try:
                global s,numbercode,username_,confirmOffer_complete_value,offer_confirm_value,offerDetail_mailto_value
                with io.open('log/offerDetail_mailto.'+numbercode+'.'+username_+'.html', 'w', encoding="utf-8") as file:
                    file.write(offerDetail_mailto_value)
                with io.open('log/offer_confirm.'+numbercode+'.'+username_+'.html', 'w', encoding="utf-8") as file:
                    file.write(offer_confirm_value)
                with io.open('log/confirmOffer_complete.'+numbercode+'.'+username_+'.html', 'w', encoding="utf-8") as file:
                    file.write(confirmOffer_complete_value)
                
               
            except Exception as e: # work on python 3.x
                print (e)
                

        def Search(self,_csrf_):
            global username_
            try:
                postdata ={'templateName':'Hirabari','_searchSynonymFlag':'on','category':'0','_userKbnLimit':'on','_userKbnLimit':'on','javaScriptEffectiveFlag':'true',
                        'offerDetailForm.templateSeq':'','serialOfferList':'','null.currentPage':'1','null.displayCount':'20',
                        '_csrf':_csrf_}
                self.Setcookies('https://www.shinsei.e-aichi.jp/pref-aichi-police-u/offer/offerList_initDisplay')
                url='https://www.shinsei.e-aichi.jp/pref-aichi-police-u/offer/offerList_searchOfferList'
                r = s.post(url, data =postdata,headers=self.getheader('offerList_searchOfferList'),timeout=3)
                print('offerList_searchOfferList:',r.status_code,r.elapsed.total_seconds())
                self.Setcookies(url)
                
                # print(r.request.headers)
                # url='https://www.shinsei.e-aichi.jp/pref-aichi-police-u/offer/offerList_movePage?dispPage=50'
                # r = s.get(url,headers=self.getheader('offerList_movePage'))
                # self.Setcookies(url)
                print(r.status_code,username_,("ようこそ、" in str(r.text)))
                
                return r.text       
            except Exception as e: # work on python 3.x
                print('offerList_searchOfferList ','err')
                return None       
       
        def checksign(self):
            global _csrf,is_logined
            self.Search(_csrf)




        def GetTimeOpen(self,str_):
            global _csrf,is_logined,numbercode,choiceid
            soup = BeautifulSoup(html.unescape(str_), "html.parser")
            find_element = soup.find_all('li', class_="c-box--cardList__item")
            for element in find_element:
                text=element.get_text().replace('\n','')
                if ('当日限' in text):
                # if ('＜11月16日(木) 10:30～11:45＞[平針]' in text):
                    value=element.find('input').get('value')
                    numbercode=value
                    return True,value
            return False,' '
                    
                    
                    
                    

        def Runonlyday(self):
            global _TRANSACTION_TOKEN,_csrf,s,numbercode

            while True:
                now = datetime.datetime.now()
                alarm_time1 = datetime.datetime.combine(now.date(), datetime.time(5, 29, 40))# khởi động
                alarm_time2 = datetime.datetime.combine(now.date(), datetime.time(5, 32, 00))# khởi động
                if (alarm_time1<=now<=alarm_time2):
                    try:
                        url='https://www.shinsei.e-aichi.jp/pref-aichi-police-u/offer/offerList_initDisplay'
                        r = s.get(url,headers=self.getheader('offerList_initDisplay'),timeout=2)
                        print('offerList_initDisplay:',r.status_code,r.elapsed.total_seconds())
                        
                        self.Setcookies(url)
                        is_,number=self.GetTimeOpen(r.text)
                        if (is_):
                            self.Run(1,number)
                            return None
                    except Exception as e:
                        print(e)
                elif (now>=alarm_time2):
                     time.sleep(1000)
                else:
                    time.sleep(randrange(2, 7))
                    self.checksign()  
            







        countcheck=0
        def Process(self,csrf,choiceid_,numbercode_):
            global s,html_
            global ten,ho,tenka,hoka,sex,sinhnhat,phone,datnuoc,datnuocbang
            global numbercode,choiceid
            pos=randrange(600, 1000)
            

            while True:
                
                # print(self.countcheck)
                # self.countcheck=self.countcheck+1
                # if self.countcheck>pos:
                #     s=requests.Session()
                #     self.useragent=self.ua.getRandom['useragent']
                #     ten,ho,tenka,hoka,sex,sinhnhat,phone,datnuoc,datnuocbang=self.random_name_sex_phone_vv()
                #     # self.getrandomproxy()
                #     usname,passs=self.getAccounts()
                #     print(usname,passs)
                #     is_login= self.login(usname,passs)
                #     if is_login==True:
                #         pos=randrange(500, 1000)
                #         print("chuyển tài khoản")
                #         self.countcheck=0
                        
                #     time.sleep(1)
                    
                
                is_click,html_=self.offerList_detailTop_check(numbercode)
             
                if is_click:
                    # time.sleep(randrange(0, 4)*0.1)
                    y=0
                    for i in range(3):
                        y=i
                        html__=self.offerDetail_mailto(html_)
                        if html__==None:
                            print(numbercode,i,'mailto...')
                        else:
                            html_=html__
                            y=0
                            break
                    if (y>=2):continue
                
                    if (choiceid_==0 or choiceid_==1):
                        y=0
                        for i in range(3):
                            y=i
                            ok, html__=self.offer_confirm_Hirabari(html_)
                            if ok==True:
                                html_=html__
                                y=0
                                break
                            else:
                                print(numbercode,i,'offer_confirm...')
                        if (y>=2):continue
                        
                    # elif (choiceid_==2):
                    #     y=0
                    #     for i in range(3):
                    #         y=i
                    #         ok, html__=self.offer_confirm_HGY(html_)
                    #         if ok==True:
                    #             html_=html__
                    #             y=0
                    #             break
                    #         else:
                    #             print(numbercode,i,'offer_confirm...')
                    #     if (y>=2):continue
                        
                    y=0
                    for i in range(3):    
                        y=i
                        html__=self.confirmOffer_complete(html_)
                        if html__==None:
                            print(numbercode,i,'offer_complete...')
                        else:
                            html_=html__
                            self.Print_log() 
                            exit()
                       
                now = datetime.datetime.now()
                alarm_time_run = datetime.datetime.combine(now.date(), datetime.time(5, 29, 20))#login 
                alarm_time_exit = datetime.datetime.combine(now.date(), datetime.time(5, 36, 0))#login 
                if now>alarm_time_exit:
                    print('Kết thúc rồi!')
                    time.sleep(5)
                    exit()
                elif now<alarm_time_run:
                    time.sleep(randrange(3, 7))
                        
              
        def process_(self,code):
            global _csrf,is_logined,numbercode,choiceid,s,html_,confirmOffer_complete_value,offer_confirm_value,offerDetail_mailto_value
            confirmOffer_complete_value=' '
            offer_confirm_value=' '
            offerDetail_mailto_value=' '
            numbercode=code
            is_click,html_=self.offerList_detailTop_check(numbercode)
            if (is_click):
                html_=self.offerDetail_mailto(html_)
                ok, html_=self.offer_confirm_Hirabari(html_)
                # ok, html_=self.offer_confirm_HGY(html_)
                html_=self.confirmOffer_complete(html_)
                self.Print_log() 
          


        def Run(self,choiceid_,code):
            global _csrf,is_logined,numbercode,choiceid
            numbercode=code
            choiceid=choiceid_
            self.Process(_csrf,choiceid_,numbercode)
            


        def test(self):
            print(self.errstr)
        def stop(self):
            exit()









# print(hh.getheader('offerList_searchOfferList'))
# is_login= hh.login('onsenchyan@gmail.com','123456')
# print(is_login)
# f = open("confirmOffer_complete.84265.ferreiramakson2015.gmail.com.html", "r", encoding="utf-8")
# soup = BeautifulSoup(html.unescape(f.read()), "html.parser")
# if hh.errstr in soup.get_text():
#     print('Có đồ')
# hh.getrandomproxy()
