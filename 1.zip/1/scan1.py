# - *- coding: utf- 8 - *
# https://203.182.213.87
import requests
import os
import io
import re
import locale
from datetime import datetime
from requests_toolbelt import MultipartEncoder
os.chdir(os.path.dirname(os.path.abspath(__file__)))
import json
from client_s_black import HumanRun
from random import randrange
import datetime
import time
import  subprocess
import socket
import sys
import threading
import multiprocessing
sys.setrecursionlimit(100000) 
import html
from bs4 import BeautifulSoup
from fake_useragent import UserAgent
import random
from urllib3.util import parse_url, Url
from urllib.parse import quote




os.chdir(os.path.dirname(os.path.abspath(__file__)))
list_dates={}
s = requests.Session() 
count_pip=0
users=[]
ua = UserAgent()
useragent=None
# print(ua.getRandom['useragent'])
Referer=''
header={}

list_info_random={}
list_info_random_tmp={}

list_info_chidinh={}
list_info_chidinh_tmp={}

list_accounts={}
list_accounts_tmp={}
list_proxy={}


def getheader(id):
    global header
    path=''
    if (id=="offerList_initDisplay"):
        path='data/header/offerList_initDisplay.txt'
    elif (id=="offerList_searchOfferList"):
        path='data/header/offerList_searchOfferList.txt'
    elif (id=="offerList_movePage"):
        path='data/header/offerList_movePage.txt'
    elif (id=="userLogin"):
        path='data/header/userLogin.txt'
    elif (id=="userLogin_login"):
        path='data/header/userLogin_login.txt'
    elif (id=="offerList_detail"):
        path='data/header/offerList_detail.txt'
    elif (id=="offerDetail_mailto"):
        path='data/header/offerDetail_mailto.txt'
    elif (id=="offer_confirm"):
        path='data/header/offer_confirm.txt'
    elif (id=="confirmOffer_complete"):
        path='data/header/confirmOffer_complete.txt'


    with open(path, encoding='utf8') as f:
        for line in f:
            txt=line.strip()
            x = txt.split(":")
            if (len(x)>0):
                header[x[0]]=x[1].strip()
    header['User-Agent']=useragent
    if Referer!='':header['Referer']=Referer
    return header
def Setcookies(refurl):
    global s , Referer
    s.cookies.set('CookiePclogoUrl','downloader?fileId=3536c8be98d800ca5aaaf360c4435a1e2b16a906f2edeadef6a693f351e4be3edade5fc9b40044471d35879cab1d4a1c02e82327b898810da8484b57edfc55cd20150305015150')
    s.cookies.set('cookieColorCss','title')
    s.cookies.set('CookieSplogoUrl','downloader?fileId=3536c8be98d800ca5aaaf360c4435a1e2b16a906f2edeadef6a693f351e4be3e0e5898d4969455051d35879cab1d4a1c02e82327b898810da8484b57edfc55cd20150305015150')
    s.cookies.set('CookiePcHelpUrl','/help/PREFAC/')
    s.cookies.set('CookieSpHelpUrl','/help/PREFAC/')
    s.cookies.set('CookiePcFaqUrl','/help/PREFAC/faq4-2.htm')
    s.cookies.set('CookieSpFaqUrl','/help/PREFAC/faq4-2.htm')
    s.cookies.set('CookieDefaultColor','b')
    s.cookies.set('CookieFontOn','true')
    if (refurl!=None): Referer=refurl

# Str_match=["Hirabari Exchanging Foreign Driver's License","Tosan Exchanging Foreign Driver's License","TGY","HGY"]
Str_match=["Hirabari Exchanging Foreign Driver's License","Tosan Exchanging Foreign Driver's License"]


def gen_phone():
    return str(random.choice(['080-','070-','090-']))+str(''.join(random.choices('0123456789', k = random.randint(3,4))))+'-'+ str(''.join(random.choices('0123456789', k = 4)))#電話番号

def generatebirth():
    for i in range(0,5000):
        DOB = (random.choice(["1980", "1981", "1982", "1983", "1984", "1985", "1986", 
        "1987", "1988", "1989", "1990", "1991", "1992", "1993", "1994", "1996", 
        "1997", "1998", "1999", "2000"])+random.choice(["01", "02", "03", "04", "05", "06", "07", "08", "09", 
        "10", "11", "12"]) + random.choice(["01", "02", "03", "04", "05", "06", 
        "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", 
        "20", "21", "22", "23", "24", "25", "26", "27", "28"]))
        return DOB
def getinfor(is_acc):
    global list_proxy,list_info_chidinh,list_accounts,list_info_random
    if (len(list_proxy)<=0):getproxylist()
    proxy_value=list_proxy.popitem()[1]
    if (len(list_info_chidinh)>0):
        info_value=list_info_chidinh.popitem()[1]
    else:
        po =random.randint(0,len(list_info_random)-1)
        info_value=  list_info_random[po]
    if is_acc==None:
        if  len(list_accounts)<=0:
            return None
        acc_info=list_accounts.popitem()
    else:acc_info=is_acc
    app=proxy_value+acc_info+info_value
    json_data = json.dumps(app)
    # print(str(json_data))
    hex_value=str(json_data).encode("utf-8").hex()
    return str(hex_value)
def add_creds_to_proxy_url( url, username, password):
            url_dict = parse_url(url)._asdict()
            url_dict['auth'] = username + ':' + quote(password, '')
            return Url(**url_dict).url

def setproxy(list_):
            global s
    # while True:
        # try:
            s = None
            s = requests.Session() 
            proxy_url_credentials = add_creds_to_proxy_url(str(list_[0]), str(list_[1]), str(list_[2]))
            proxies = {'http': proxy_url_credentials, 'https': proxy_url_credentials}
            s.proxies.update(proxies)
            print('da cai proxy: ',list_)
            r=s.get('https://www.myip.com/', verify=False)
            soup = BeautifulSoup(html.unescape(r.text), "html.parser")
            ip=soup.find("span", {"id": "ip"})
            print(ip)
            # break
        # except: print()
    

def getproxylist():
    global list_proxy
    # ip_ = input("ip input:")
    # ip_ ='64.176.38.151'
    with open('proxy.txt', encoding='utf8') as f:
        for line in f:
            txt=line.strip()
            # x = txt.split("	")
            # if (len(x)>=3):
            #     list_proxy[x[1]]=x[0],x[1],x[2]
            x = txt.split(":")
            if (len(x)>=4):
                list_proxy[x[1]]='http://'+x[0]+':'+x[1],x[2],x[3]
                # list_proxy[x[1]]='http://'+ip_+':'+x[1],x[2],x[3]

    return list_proxy


def getAccounts():
    global list_accounts
    with open('data/user.txt', encoding='utf8') as f:
        for line in f:
            txt=line.strip()
            x = txt.split("	")
            if (len(x)>=2):
                list_accounts[x[0]]=x[1]
                list_accounts_tmp[x[0]]=x[1]
    return list_accounts
    
    
def get_contry(idcountry):
    datnuoc_,datnuocbang_='',''
    if idcountry=="1":#vietnam
        datnuoc_='ベトナム'
        datnuocbang_='ベトナム'
    elif idcountry=="0":# brazil
        datnuoc_='ブラジル'
        datnuocbang_='ブラジル'
    elif idcountry=="2":# philippin
        datnuoc_='フィリピン'
        datnuocbang_='フィリピン'
    elif idcountry=="3":# indonesia
        datnuoc_='インドネシア'
        datnuocbang_='インドネシア'
    return datnuoc_,datnuocbang_
    
def getlistinfo_chidinh():
    global list_info_chidinh
    # ten,ho,tenka,hoka,sex,sinhnhat,phone,datnuoc,datnuocbang='','','','','','','','',''
    count_=0
    with open('data/inforuserchidinh.txt', encoding='utf8') as f:
        for line in f:
            txt=line.strip()
            x = txt.split("	")
            if (len(x)>=5):
                # tmp_=x[1],x[0],'','',x[3],x[2],x[4],'151','150'
                datnuoc_,datnuocbang_=get_contry(x[4])
                list_info_chidinh[count_]=x[1],x[0],'','',x[3],x[2],x[5],datnuoc_,datnuocbang_
                count_=count_+1
    return list_info_chidinh

def random_name_sex_phone_vv():
        global list_info_random
        count_=0
        if len(list_info_random)<1:
            with open('data/hoten.txt', encoding='utf8') as f:
                for line in f:
                    txt=line.strip()
                    x = txt.split("	")
                    if (len(x)>=5):
                        idcountry=x[5]
                        datnuoc,datnuocbang=get_contry(idcountry)
                        phone=str(gen_phone())
                        sinhnhat=generatebirth()
                        list_info_random[count_]=x[2],x[1],x[3],x[0],x[4] ,sinhnhat,phone,datnuoc,datnuocbang
                        count_=count_+1
        shuffled = list(list_info_random.values())
        random.shuffle(shuffled)
        list_info_random=dict(zip(list_info_random, shuffled))
        random.shuffle(list_info_random)
        po =random.randint(0,len(list_info_random)-1)
        return list_info_random[po]
     


def check_match(str_text):
    for x in range(0, len(Str_match)):
        if (Str_match[x] in str_text ):
            # print(Str_match[x])
            return x
    return -1
def check_time_in_date_now(text):
    result = re.search('受付開始日時(.*)受付終了日時', text)
    timeopen=str(result.group(1))
    timeopen=timeopen.replace(' ','')
    timeopen=timeopen.replace('　','')
    # locale.setlocale(locale.LC_ALL, 'jpn') 
    locale.setlocale(locale.LC_ALL, 'japanese') 
    
    datetime_object = datetime.datetime.strptime(timeopen, '%Y年%m月%d日%H時%M分')
    now = datetime.datetime.now()
    # print(datetime_object.date(),now.date())
    return datetime_object.date()==now.date()

# print(check_match("【11月09日(木)】[平針] 運転免許学科試験＜普通第一種のみ／県外教習所卒業者・再受験者に限る＞HGY"))

def getTokenFromHtml(strhtml):
    soup = BeautifulSoup(html.unescape(strhtml), "html.parser")
    value1,value2="",""
    try:
        value1 = soup.find('input', {'name': '_TRANSACTION_TOKEN'}).get('value')
        # print(value)
    except Exception as e:
        print("Err:","_TRANSACTION_TOKEN")
    try:
        value2 = soup.find('input', {'name': '_csrf'}).get('value')
        print(value2)
    except Exception as e:
        print("Err:","_csrf")
    return value1,value2



def run_server(user, pass_,choiceid,code):
        
        p=subprocess.Popen(["start", "cmd", "/k", "python server.py "+str(user) + ' ' + str(pass_) + ' '+str(choiceid)+' '+str(code)], shell = True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
def run_server(id,choice_, info):
    p=subprocess.Popen(["start", "cmd", "/k", "python server.py "+str(id) + ' ' + str(choice_) + ' ' + str(info) ], shell = True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
       

def get_list():
    global username_,s
    # r = s.get('https://www.shinsei.e-aichi.jp/pref-aichi-police-u/offer/offerList_initDisplay')
    url='https://www.shinsei.e-aichi.jp/pref-aichi-police-u/offer/offerList_initDisplay'
    r = s.get(url,headers=getheader('offerList_initDisplay'))
    # print(r.request.headers)
    print('offerList_initDisplay:',r.status_code,r.elapsed.total_seconds())
    Setcookies(url)
    # url='https://www.shinsei.e-aichi.jp/pref-aichi-police-u/offer/offerList_movePage?dispPage=50'
    # r = s.get(url,headers=getheader('offerList_movePage'))
    # # print(r.request.headers)
    # print('offerList_movePage:',r.status_code,r.elapsed.total_seconds())
    # Setcookies(url)
    return r.text
    # GetTimeOpen(r.text)
def Search(_csrf_,value_):
    global username_,s
    try:
        postdata ={'templateName':value_,'_searchSynonymFlag':'on','category':'0','_userKbnLimit':'on','_userKbnLimit':'on','javaScriptEffectiveFlag':'true',
                'offerDetailForm.templateSeq':'','serialOfferList':'','null.currentPage':'1','null.displayCount':'20',
                '_csrf':_csrf_}
        Setcookies('https://www.shinsei.e-aichi.jp/pref-aichi-police-u/offer/offerList_initDisplay')
        url='https://www.shinsei.e-aichi.jp/pref-aichi-police-u/offer/offerList_searchOfferList'
        r = s.post(url, data =postdata,headers=getheader('offerList_searchOfferList'),timeout=3)
        print('offerList_searchOfferList:',r.status_code,r.elapsed.total_seconds())
        # Setcookies(url)
        return r.text       
    except Exception as e: # work on python 3.x
        print('offerList_searchOfferList ',e)
        return None      


def RunServer_(code,codetext,info):
    bytes_obj = bytes.fromhex(str(info))
    result_string = bytes_obj.decode('utf-8')
    json_data = json.loads(str(result_string))
    print(codetext,code,json_data)
    # server.timelogin(None,code,choiceid,info)
    bot=HumanRun()
    bot.Setup___(json_data,codetext)
    # bot.getrandomproxy()
    bot.setproxy(json_data[0],json_data[1],json_data[2])
    is_login= bot.login(json_data[3],json_data[4])
    if (is_login):
        bot.Run(1,code)

def getdates():
    with open('data/dates.txt', encoding='utf8') as f:
        count_=0
        for line in f:
            txt=line.strip()
            list_dates[count_]=txt
            count_=count_+1
    return list_dates

def check_dates(str_):
    global list_dates
    for date in list_dates:
        if list_dates[date] in str_ :
            return True
    return False
    
def GetTimeOpen(str_):
        
        soup = BeautifulSoup(html.unescape(str_), "html.parser")
        # print(soup.getText())
    # try:
        find_element = soup.find_all('li', class_="c-box--cardList__item")
        for element in find_element:
            # text=element.get_text().replace('\n','')
            h4=element.find("h4", {"class" : 'c-box--cardList__item_h4'})
            print(h4.get_text())
            value=str(element.find('input').get('value'))
            print(value)
            list_accounts_tmp=list_accounts.copy()
            while len(list_accounts_tmp)>0:
                item=list_accounts_tmp.popitem()
                print(value,item)
                TMP=getinfor(item)
                multiprocessing.Process(target=RunServer_, args=(value,h4.get_text(),TMP)).start()

def GetTimeOpent2(str_):
        soup = BeautifulSoup(html.unescape(str_), "html.parser")
        # print(soup.getText())
    # try:
        find_element = soup.find_all('li', class_="c-box--cardList__item")
        for element in find_element:
            # text=element.get_text().replace('\n','')
            h4=element.find("h4", {"class" : 'c-box--cardList__item_h4'})
            
            if check_match(h4.get_text())!=1: continue
            print(h4.get_text())
            value=str(element.find('input').get('value'))
            print(value)
            list_accounts_tmp=list_accounts.copy()
            while len(list_accounts_tmp)>0:
                item=list_accounts_tmp.popitem()
                print(value,item)
                TMP=getinfor(item)
                multiprocessing.Process(target=RunServer_, args=(value,h4.get_text(),TMP)).start()

def getTokenFromHtml(strhtml):
    soup = BeautifulSoup(html.unescape(strhtml), "html.parser")
    value1,value2="",""
    try:
        value1 = soup.find('input', {'name': '_TRANSACTION_TOKEN'}).get('value')
        # print(value)
    except Exception as e:
        print("Err:","_TRANSACTION_TOKEN")
    try:
        value2 = soup.find('input', {'name': '_csrf'}).get('value')
        print(value2)
    except Exception as e:
        print("Err:","_csrf")
    return value1,value2


if __name__ == "__main__":
    useragent=ua.getRandom['useragent']
    getlistinfo_chidinh()
    getAccounts()
    getproxylist()
    getdates()
    random_name_sex_phone_vv()
    if (len(list_proxy)<=0):getproxylist()
    proxy_value=list_proxy.popitem()[1]
    print(proxy_value)
    # setproxy(proxy_value)
    now = datetime.datetime.now()
    html_=get_list()
    value1,value2=getTokenFromHtml(html_)
    while True:
        now = datetime.datetime.now()
        alarm_time= datetime.datetime.combine(now.date(), datetime.time(5, 25, 0))# khởi động
        if (now>=alarm_time):
            print(now,': Đang chạy rồi...')
            count_=0
            with open('data/dates.txt', encoding='utf8') as f:
                for line in f:
                    if (line.strip().replace('\ufeff','')==''):continue
                    count_=count_+1
                    print(count_)
                    txt=line.strip().replace('\ufeff','')
                    print(txt)
                    html_=Search(value2,txt)
                    GetTimeOpen(html_)

            if count_==0:
                # html_=Search(value2,txt)
                GetTimeOpent2(html_)

            break
        else:
            print(now,'waiting...')
            time.sleep(2)




        


