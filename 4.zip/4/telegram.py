import requests


def send_to_telegram(message):

    apiToken = '6501118095:AAHxIV2VDlQL84X3werSGmmROe4ttGMVBR8'
    chatID = '1566772671'
    apiURL = f'https://api.telegram.org/bot{apiToken}/sendMessage'

    try:
        response = requests.post(apiURL, json={'chat_id': chatID, 'text': message})
        # print(response.text)
    except Exception as e:
        print(e)

def send_log(message):

    apiToken = '6965429766:AAGRQyPrzCxqPnBYGqBjeK9r4KVHZRoISPg'
    chatID = '1566772671'
    apiURL = f'https://api.telegram.org/bot{apiToken}/sendMessage'

    try:
        response = requests.post(apiURL, json={'chat_id': chatID, 'text': message})
        # print(response.text)
    except Exception as e:
        print(e) 



# while True:
#     url='https://www.shinsei.e-aichi.jp/pref-aichi-police-u/offer/offerList_initDisplay'
#     r = requests.get(url)
#     print('offerList_initDisplay:',r.status_code,r.elapsed.total_seconds())